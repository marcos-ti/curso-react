import React from "react";

export default {
  title: "Introduction|Welcome",
};

export const toAutoEscolaNardini = () => (
  <div>
    <h1>Auto Escola Nardini</h1>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione obcaecati
      distinctio ab magni fugit dolor, esse minus voluptate repudiandae! Itaque
      sunt totam soluta iure libero quia fugiat fugit ratione aperiam!
    </p>
  </div>
);
